# -*- coding: utf-8 -*-
"""
NÉCTAR — Autorização de saída (programa da impressora)
------------------------------------------------------
Faz tudo sozinho, sem depender do navegador:
  1. acha o Arduino + RC522 em qualquer porta COM (mesmo se a porta mudar);
  2. quando a tag é aproximada, busca o aluno no Supabase;
  3. imprime a autorização DIRETO na térmica (ESC/POS, sem driver/folha A4);
  4. responde ao Arduino "OK" (1 bipe) ou "ERRO" (2 bipes).
O site http://127.0.0.1:8137 só mostra o status, a prévia e o histórico.

Uso: "Iniciar Néctar Impressão.bat". Deixe a janela aberta (pode minimizar).
Só usa bibliotecas que já vêm com o Python — não precisa instalar nada.
"""
import ctypes
import json
import os
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import winreg
from ctypes import wintypes
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ===================== CONFIGURAÇÃO =====================
PORTA = 8137
# Sites que podem usar este programa (o próprio endereço local + o site publicado no GitHub Pages).
# Qualquer outro site aberto neste computador é bloqueado — ninguém imprime "de fora".
SITE_ONLINE = 'https://theoecit-hue.github.io'        # preenchido na publicação, ex.: 'https://usuario.github.io'
SUPABASE_URL = 'https://tbsykzgbobftrygraiak.supabase.co'
SUPABASE_KEY = 'sb_publishable_ZHSLwyX9Aa2U3pzd0PE0Ow_TD4WFpdP'   # chave pública — NUNCA a service_role
ARDUINO_PORTA = ''     # vazio = procura sozinho; ou fixe, ex.: 'COM8'
IMPRESSORA = ''        # vazio = impressora padrão do Windows; ou o nome exato, ex.: 'HPRT MPT-II(1)'
COLUNAS = 32           # caracteres por linha: 32 para bobina 58 mm, 24 para bobina 38-40 mm
ACENTOS = True         # se sair letra estranha no lugar de "ç/ã/é", troque para False
AVANCO_FINAL = 3       # linhas em branco no fim (para conseguir destacar o papel)
CORTAR = True          # envia comando de corte (ignorado por impressoras sem guilhotina)
REPETICAO_SEG = 10     # a mesma tag dentro deste intervalo não imprime de novo
# ========================================================

ESC, GS = b'\x1b', b'\x1d'
PASTA = os.path.dirname(os.path.abspath(__file__))
TIPOS = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
         '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml'}


# =============================================================
#  COMPROVANTE EM ESC/POS
# =============================================================
def txt(s: str) -> bytes:
    if not ACENTOS:
        s = ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')
    return s.encode('cp850', errors='replace')


def quebrar(s: str, largura: int) -> list:
    linhas, atual = [], ''
    for p in s.split():
        if len(atual) + len(p) + (1 if atual else 0) <= largura:
            atual = f'{atual} {p}' if atual else p
        else:
            if atual:
                linhas.append(atual)
            while len(p) > largura:
                linhas.append(p[:largura]); p = p[largura:]
            atual = p
    if atual:
        linhas.append(atual)
    return linhas


def icone_check(tam=88) -> bytes:
    """Desenha o ✓ dentro de um círculo como imagem (GS v 0)."""
    c = tam / 2
    r_ext, r_int = tam * 0.48, tam * 0.39
    pts = [(tam * .27, tam * .52), (tam * .43, tam * .68), (tam * .73, tam * .36)]
    esp = tam * 0.075

    def dist_seg(px, py, a, b):
        (x1, y1), (x2, y2) = a, b
        dx, dy = x2 - x1, y2 - y1
        t = max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)))
        return ((px - x1 - t * dx) ** 2 + (py - y1 - t * dy) ** 2) ** .5

    bpl = (tam + 7) // 8
    dados = bytearray()
    for y in range(tam):
        linha = bytearray(bpl)
        for x in range(tam):
            d = ((x + .5 - c) ** 2 + (y + .5 - c) ** 2) ** .5
            preto = r_int <= d <= r_ext or min(dist_seg(x + .5, y + .5, pts[0], pts[1]),
                                               dist_seg(x + .5, y + .5, pts[1], pts[2])) <= esp
            if preto:
                linha[x // 8] |= 0x80 >> (x % 8)
        dados += linha
    return GS + b'v0\x00' + bytes([bpl % 256, bpl // 256, tam % 256, tam // 256]) + bytes(dados)


ICONE = icone_check()


def montar_comprovante(nome: str, hora: str, data: str) -> bytes:
    L = COLUNAS
    centro, esq = ESC + b'a\x01', ESC + b'a\x00'
    neg_on, neg_off = ESC + b'E\x01', ESC + b'E\x00'
    normal = GS + b'!\x00'
    duplo = GS + b'!\x11'          # largura e altura dobradas
    alto = GS + b'!\x01'           # só altura dobrada
    inv_on, inv_off = GS + b'B\x01', GS + b'B\x00'
    fonteB, fonteA = ESC + b'M\x01', ESC + b'M\x00'
    nl = b'\n'
    traco = txt('-' * L) + nl

    b = bytearray()
    b += ESC + b'@'                                  # reinicia a impressora
    b += ESC + b't\x02'                              # tabela de caracteres PC850 (acentos)
    b += ESC + b'3\x18'                              # espaçamento entre linhas mais justo
    b += centro + neg_on + duplo + txt('NÉCTAR') + nl + normal + neg_off
    b += txt('CONTROLE DE ACESSO ESCOLAR'[:L]) + nl
    b += traco
    b += ICONE + nl
    titulo = ' AUTORIZAÇÃO DE SAÍDA '
    b += neg_on + alto + inv_on + txt(titulo[:L]) + inv_off + normal + neg_off + nl + nl
    for l in quebrar('A Direção da escola autoriza a saída do aluno(a) do ambiente escolar.', L):
        b += txt(l) + nl
    b += nl + esq
    b += txt('Aluno(a): ') + neg_on
    rot = len('Aluno(a): ')
    partes = quebrar(nome, L - rot) or ['']
    b += txt(partes[0]) + nl
    for p in partes[1:]:
        b += txt(' ' * rot + p) + nl
    b += neg_off
    b += txt('Horário:  ') + neg_on + alto + txt(hora) + normal + neg_off + nl
    b += txt('Data:     ') + txt(data) + nl
    b += nl + centro + neg_on
    for l in quebrar('Apresente este comprovante ao porteiro.', L):
        b += txt(l) + nl
    b += neg_off + traco
    b += neg_on + txt('NÉCTAR') + neg_off + nl
    b += fonteB + txt('Tecnologia a favor da nossa escola.') + fonteA + nl
    b += ESC + b'd' + bytes([AVANCO_FINAL])
    if CORTAR:
        b += GS + b'V\x01'
    return bytes(b)


# =============================================================
#  IMPRESSORA (modo RAW do Windows — ignora o tamanho de papel do driver)
# =============================================================
class DOC_INFO_1(ctypes.Structure):
    _fields_ = [('pDocName', wintypes.LPWSTR), ('pOutputFile', wintypes.LPWSTR), ('pDatatype', wintypes.LPWSTR)]


def _winspool():
    w = ctypes.WinDLL('winspool.drv', use_last_error=True)
    w.OpenPrinterW.argtypes = [wintypes.LPWSTR, ctypes.POINTER(wintypes.HANDLE), ctypes.c_void_p]
    w.StartDocPrinterW.argtypes = [wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(DOC_INFO_1)]
    w.StartDocPrinterW.restype = wintypes.DWORD
    w.StartPagePrinter.argtypes = [wintypes.HANDLE]
    w.WritePrinter.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    w.EndPagePrinter.argtypes = [wintypes.HANDLE]
    w.EndDocPrinter.argtypes = [wintypes.HANDLE]
    w.ClosePrinter.argtypes = [wintypes.HANDLE]
    w.GetDefaultPrinterW.argtypes = [wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    return w


def nome_impressora() -> str:
    if IMPRESSORA:
        return IMPRESSORA
    w = _winspool()
    n = wintypes.DWORD(0)
    w.GetDefaultPrinterW(None, ctypes.byref(n))
    buf = ctypes.create_unicode_buffer(n.value or 1)
    if not w.GetDefaultPrinterW(buf, ctypes.byref(n)):
        raise RuntimeError('Nenhuma impressora padrão definida no Windows.')
    return buf.value


trava_impressao = threading.Lock()


def imprimir_raw(dados: bytes) -> str:
    with trava_impressao:
        w = _winspool()
        nome = nome_impressora()
        h = wintypes.HANDLE()
        if not w.OpenPrinterW(nome, ctypes.byref(h), None):
            raise RuntimeError(f'Não consegui abrir a impressora "{nome}".')
        try:
            doc = DOC_INFO_1('Nectar - Autorizacao de saida', None, 'RAW')
            if not w.StartDocPrinterW(h, 1, ctypes.byref(doc)):
                raise RuntimeError('A impressora recusou o modo RAW.')
            w.StartPagePrinter(h)
            escrito = wintypes.DWORD(0)
            buf = ctypes.create_string_buffer(dados, len(dados))
            w.WritePrinter(h, buf, len(dados), ctypes.byref(escrito))
            w.EndPagePrinter(h)
            w.EndDocPrinter(h)
        finally:
            w.ClosePrinter(h)
        return nome


def imprimir_aluno(nome: str, quando: datetime) -> str:
    return imprimir_raw(montar_comprovante(nome, quando.strftime('%H:%M'), quando.strftime('%d/%m/%Y')))


# =============================================================
#  SUPABASE
# =============================================================
def buscar_aluno(tag: str):
    url = (f'{SUPABASE_URL}/rest/v1/estudantes?select=nome,cpf,tag,turno'
           f'&tag=eq.{urllib.parse.quote(tag)}&limit=1')
    req = urllib.request.Request(url, headers={'apikey': SUPABASE_KEY, 'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=8) as r:
        dados = json.loads(r.read().decode('utf-8'))
    return dados[0] if dados else None


def salvar_autorizacao(aluno: dict, autorizado_por: str, motivo: str):
    """Grava o aviso que aparece no painel do responsável (não muda nada na impressão)."""
    corpo = json.dumps({'tag': aluno['tag'], 'cpf': aluno.get('cpf'), 'nome': aluno['nome'],
                        'autorizado_por': autorizado_por or None, 'motivo': motivo or None}).encode('utf-8')
    req = urllib.request.Request(f'{SUPABASE_URL}/rest/v1/autorizacoes', data=corpo, method='POST', headers={
        'apikey': SUPABASE_KEY, 'Content-Type': 'application/json', 'Prefer': 'return=minimal'})
    try:
        urllib.request.urlopen(req, timeout=8).close()
    except urllib.error.HTTPError as e:
        detalhe = e.read().decode('utf-8', 'replace')
        if 'autorizacoes' in detalhe and ('does not exist' in detalhe or 'schema cache' in detalhe):
            raise RuntimeError('a tabela "autorizacoes" ainda não existe — rode o autorizacoes.sql no Supabase')
        raise RuntimeError(f'Supabase recusou ({e.code}): {detalhe[:150]}')


# =============================================================
#  EVENTOS (o site lê isto para mostrar na tela)
# =============================================================
trava_eventos = threading.Lock()
eventos = []   # {id, tipo: ok | nao_cadastrada | erro | info, msg, tag, nome, hora, data}
estado = {'arduino': None, 'arduino_msg': 'Procurando o Arduino…',
          'autorizado_por': '', 'motivo': ''}   # preenchidos pelo site (aviso aos pais)
_ultimo = {'tag': '', 't': 0.0}
_trava_tag = threading.Lock()


def registrar(tipo, msg, **extra):
    with trava_eventos:
        ev = {'id': (eventos[-1]['id'] + 1) if eventos else 1, 'tipo': tipo, 'msg': msg, **extra}
        eventos.append(ev)
        del eventos[:-300]
    print(f'[{datetime.now():%H:%M:%S}] {msg}')
    return ev


def processar_tag(tag_bruta: str) -> dict:
    tag = ''.join(str(tag_bruta).split()).upper()
    if not tag:
        return {'ok': False, 'erro': 'tag vazia'}
    with _trava_tag:
        agora = time.time()
        if tag == _ultimo['tag'] and agora - _ultimo['t'] < REPETICAO_SEG:
            return {'ok': False, 'erro': f'tag {tag} lida de novo — ignorada ({REPETICAO_SEG}s)'}
        _ultimo.update(tag=tag, t=agora)
    quando = datetime.now()
    try:
        aluno = buscar_aluno(tag)
    except Exception as e:
        responder_arduino('ERRO')
        registrar('erro', f'Sem conexão com o Supabase ({e})', tag=tag)
        return {'ok': False, 'erro': 'sem conexão com o Supabase'}
    if not aluno:
        responder_arduino('ERRO')
        registrar('nao_cadastrada', f'Tag {tag} não cadastrada — nada foi impresso', tag=tag)
        return {'ok': False, 'erro': f'tag {tag} não cadastrada'}
    try:
        imprimir_aluno(aluno['nome'], quando)
    except Exception as e:
        responder_arduino('ERRO')
        registrar('erro', f'Erro na impressora: {e}', tag=tag, nome=aluno['nome'])
        return {'ok': False, 'erro': f'impressora: {e}'}
    responder_arduino('OK')
    autorizado_por, motivo = estado['autorizado_por'], estado['motivo']
    try:
        salvar_autorizacao(aluno, autorizado_por, motivo)
        aviso_ok, aviso_erro = True, None
    except Exception as e:
        aviso_ok, aviso_erro = False, str(e)
    registrar('ok', f"Autorização impressa: {aluno['nome']}", tag=tag, nome=aluno['nome'],
              hora=quando.strftime('%H:%M'), data=quando.strftime('%d/%m/%Y'),
              autorizado_por=autorizado_por, motivo=motivo, aviso_ok=aviso_ok, aviso_erro=aviso_erro)
    if not aviso_ok:
        print('   aviso aos pais NÃO enviado:', aviso_erro)
    return {'ok': True, 'nome': aluno['nome'], 'aviso_ok': aviso_ok, 'aviso_erro': aviso_erro}


# =============================================================
#  ARDUINO PELA PORTA COM (Win32 — sem instalar nada)
# =============================================================
class DCB(ctypes.Structure):
    _fields_ = [('DCBlength', wintypes.DWORD), ('BaudRate', wintypes.DWORD), ('flags', wintypes.DWORD),
                ('wReserved', wintypes.WORD), ('XonLim', wintypes.WORD), ('XoffLim', wintypes.WORD),
                ('ByteSize', ctypes.c_ubyte), ('Parity', ctypes.c_ubyte), ('StopBits', ctypes.c_ubyte),
                ('XonChar', ctypes.c_char), ('XoffChar', ctypes.c_char), ('ErrorChar', ctypes.c_char),
                ('EofChar', ctypes.c_char), ('EvtChar', ctypes.c_char), ('wReserved1', wintypes.WORD)]


class COMMTIMEOUTS(ctypes.Structure):
    _fields_ = [('ReadIntervalTimeout', wintypes.DWORD), ('ReadTotalTimeoutMultiplier', wintypes.DWORD),
                ('ReadTotalTimeoutConstant', wintypes.DWORD), ('WriteTotalTimeoutMultiplier', wintypes.DWORD),
                ('WriteTotalTimeoutConstant', wintypes.DWORD)]


k32 = ctypes.WinDLL('kernel32', use_last_error=True)
k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                            wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
k32.CreateFileW.restype = wintypes.HANDLE
k32.ReadFile.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
k32.WriteFile.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
k32.CloseHandle.argtypes = [wintypes.HANDLE]
k32.GetCommState.argtypes = [wintypes.HANDLE, ctypes.POINTER(DCB)]
k32.SetCommState.argtypes = [wintypes.HANDLE, ctypes.POINTER(DCB)]
k32.BuildCommDCBW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(DCB)]
k32.SetCommTimeouts.argtypes = [wintypes.HANDLE, ctypes.POINTER(COMMTIMEOUTS)]
INVALIDO = wintypes.HANDLE(-1).value


class Serial:
    def __init__(self, nome):
        self.nome = nome
        self.buf = b''
        self.h = k32.CreateFileW('\\\\.\\' + nome, 0xC0000000, 0, None, 3, 0, None)
        if self.h in (None, INVALIDO):
            self.h = None
            raise OSError(f'{nome} ocupada ou inexistente')
        dcb = DCB()
        dcb.DCBlength = ctypes.sizeof(DCB)
        k32.GetCommState(self.h, ctypes.byref(dcb))
        k32.BuildCommDCBW('baud=9600 parity=N data=8 stop=1 dtr=on rts=on', ctypes.byref(dcb))
        if not k32.SetCommState(self.h, ctypes.byref(dcb)):
            self.fechar()
            raise OSError(f'não consegui configurar a {nome}')
        to = COMMTIMEOUTS(50, 0, 200, 0, 500)
        k32.SetCommTimeouts(self.h, ctypes.byref(to))

    def ler_linhas(self):
        tmp = ctypes.create_string_buffer(256)
        n = wintypes.DWORD(0)
        if not k32.ReadFile(self.h, tmp, 256, ctypes.byref(n), None):
            raise OSError('Arduino desconectado')
        self.buf += tmp.raw[:n.value]
        *linhas, self.buf = self.buf.split(b'\n')
        return [l.decode('latin-1').strip() for l in linhas if l.strip()]

    def escrever(self, texto):
        dados = (texto + '\n').encode()
        n = wintypes.DWORD(0)
        k32.WriteFile(self.h, dados, len(dados), ctypes.byref(n), None)

    def fechar(self):
        if self.h:
            k32.CloseHandle(self.h)
        self.h = None


arduino = None


def responder_arduino(cmd):
    try:
        if arduino:
            arduino.escrever(cmd)
    except Exception:
        pass


def portas_candidatas():
    if ARDUINO_PORTA:
        return [ARDUINO_PORTA]
    portas = []
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DEVICEMAP\SERIALCOMM') as k:
            i = 0
            while True:
                try:
                    dispositivo, com, _ = winreg.EnumValue(k, i)
                except OSError:
                    break
                i += 1
                if 'bth' not in dispositivo.lower():        # ignora portas Bluetooth (travam ao abrir)
                    portas.append(com)
    except OSError:
        pass
    return portas


def achar_arduino():
    """Abre cada porta e espera o Arduino se apresentar (ele reinicia ao abrir a porta)."""
    for com in portas_candidatas():
        try:
            s = Serial(com)
        except OSError:
            continue
        fim = time.time() + 4
        try:
            while time.time() < fim:
                for l in s.ler_linhas():
                    if l.startswith(('PRONTO', 'TAG:', 'ERRO:')):
                        if l.startswith('ERRO:'):
                            estado['arduino_msg'] = 'RC522: ' + l[5:]
                        return s
        except OSError:
            pass
        s.fechar()
    return None


def laco_arduino():
    global arduino
    while True:
        if not arduino:
            estado['arduino'] = None
            estado['arduino_msg'] = 'Procurando o Arduino… (feche o Arduino IDE e o site principal se estiverem usando a porta)'
            s = achar_arduino()
            if not s:
                time.sleep(2)
                continue
            arduino = s
            estado['arduino'] = s.nome
            estado['arduino_msg'] = f'Arduino conectado na {s.nome} — aproxime a tag'
            registrar('info', f'Arduino conectado na {s.nome}')
        try:
            for l in arduino.ler_linhas():
                if l.startswith('TAG:'):
                    threading.Thread(target=processar_tag, args=(l[4:],), daemon=True).start()
                elif l.startswith('ERRO:'):
                    estado['arduino_msg'] = 'RC522: ' + l[5:]
        except OSError:
            registrar('info', f'Arduino desconectado da {arduino.nome} — procurando de novo…')
            arduino.fechar()
            arduino = None


# =============================================================
#  SITE LOCAL  http://127.0.0.1:8137
# =============================================================
def origens_permitidas():
    o = {f'http://127.0.0.1:{PORTA}', f'http://localhost:{PORTA}', 'null'}   # 'null' = index.html aberto direto
    if SITE_ONLINE:
        o.add(SITE_ONLINE.rstrip('/'))
    return o


class Handler(BaseHTTPRequestHandler):
    def _origem_ok(self):
        origem = self.headers.get('Origin')
        return origem is None or origem in origens_permitidas()

    def _cors(self):
        origem = self.headers.get('Origin')
        if origem and origem in origens_permitidas():
            self.send_header('Access-Control-Allow-Origin', origem)
            self.send_header('Vary', 'Origin')
            # o Chrome pede isto quando um site da internet fala com um programa deste computador
            self.send_header('Access-Control-Allow-Private-Network', 'true')

    def _json(self, cod, obj):
        corpo = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(cod)
        self._cors()
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(corpo)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(corpo)

    def do_OPTIONS(self):
        self.send_response(204 if self._origem_ok() else 403)
        self._cors()
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Max-Age', '600')
        self.end_headers()

    def do_GET(self):
        rota = self.path.split('?')[0]
        if not self._origem_ok():
            return self._json(403, {'ok': False, 'erro': 'site não autorizado'})
        if rota == '/status':
            try:
                imp, erro_imp = nome_impressora(), None
            except Exception as e:
                imp, erro_imp = None, str(e)
            return self._json(200, {'ok': True, 'impressora': imp, 'erro_impressora': erro_imp,
                                    'arduino': estado['arduino'], 'arduino_msg': estado['arduino_msg']})
        if rota == '/eventos':
            q = urllib.parse.parse_qs(self.path.partition('?')[2])
            desde = int((q.get('desde') or ['0'])[0] or 0)
            with trava_eventos:
                novos = [e for e in eventos if e['id'] > desde]
            return self._json(200, {'eventos': novos})
        # arquivos do site
        caminho = rota.lstrip('/') or 'index.html'
        arq = os.path.normpath(os.path.join(PASTA, urllib.parse.unquote(caminho)))
        tipo = TIPOS.get(os.path.splitext(arq)[1].lower())
        if not arq.startswith(PASTA) or not tipo or not os.path.isfile(arq):
            return self._json(404, {'ok': False, 'erro': 'arquivo não encontrado'})
        with open(arq, 'rb') as f:
            corpo = f.read()
        self.send_response(200)
        self.send_header('Content-Type', tipo)
        self.send_header('Content-Length', str(len(corpo)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(corpo)

    def do_POST(self):
        if not self._origem_ok():
            return self._json(403, {'ok': False, 'erro': 'site não autorizado'})
        try:
            n = int(self.headers.get('Content-Length', 0))
            d = json.loads(self.rfile.read(n).decode('utf-8') or '{}')
        except Exception:
            return self._json(400, {'ok': False, 'erro': 'pedido inválido'})
        if self.path.startswith('/config'):                   # quem autoriza + motivo (vindos do site)
            estado['autorizado_por'] = str(d.get('autorizado_por', '')).strip()[:80]
            estado['motivo'] = str(d.get('motivo', '')).strip()[:200]
            return self._json(200, {'ok': True})
        if self.path.startswith('/tag'):                      # tag digitada / leitor teclado
            return self._json(200, processar_tag(d.get('tag', '')))
        if self.path.startswith('/teste'):                    # comprovante de teste
            try:
                imp = imprimir_aluno('ALUNO(A) DE TESTE', datetime.now())
                registrar('info', 'Comprovante de teste impresso')
                return self._json(200, {'ok': True, 'impressora': imp})
            except Exception as e:
                return self._json(200, {'ok': False, 'erro': str(e)})
        if self.path.startswith('/reimprimir'):               # reimprime o último aluno
            with trava_eventos:
                ult = next((e for e in reversed(eventos) if e['tipo'] == 'ok'), None)
            if not ult:
                return self._json(200, {'ok': False, 'erro': 'nenhuma autorização para reimprimir'})
            try:
                imprimir_aluno(ult['nome'], datetime.now())
                registrar('info', f"Reimpresso: {ult['nome']}")
                return self._json(200, {'ok': True, 'nome': ult['nome']})
            except Exception as e:
                return self._json(200, {'ok': False, 'erro': str(e)})
        return self._json(404, {'ok': False, 'erro': 'rota inexistente'})

    def log_message(self, *a):
        pass


if __name__ == '__main__':
    url = f'http://127.0.0.1:{PORTA}/'
    try:
        servidor = ThreadingHTTPServer(('127.0.0.1', PORTA), Handler)
    except OSError:
        print('O programa já estava aberto — só abrindo o site.')
        webbrowser.open(url)
        raise SystemExit
    try:
        imp = nome_impressora()
    except Exception as e:
        imp = f'(erro: {e})'
    print('=' * 56)
    print(' NÉCTAR — Autorização de saída')
    print(f' Impressora: {imp}')
    print(f' Site: {url}')
    print(' NÃO feche esta janela (pode minimizar).')
    print('=' * 56)
    threading.Thread(target=laco_arduino, daemon=True).start()
    webbrowser.open(url)
    servidor.serve_forever()
