@echo off
rem Abre o programa da impressora termica (janela minimizada). Ele mesmo abre o site no navegador.
cd /d "%~dp0"
where python >nul 2>nul || (echo Python nao encontrado. Instale em python.org & pause & exit /b)
start "Nectar - impressora (NAO FECHE)" /min python "%~dp0servidor_impressora.py"
